
@include('MainLayouts/header')
@include('MainLayouts/mainheader')
    @include('MainLayouts/leftsidebar')
    @include('Admin/layouts/Admin/viewCreateAdmin') 
@include('MainLayouts/footer')
