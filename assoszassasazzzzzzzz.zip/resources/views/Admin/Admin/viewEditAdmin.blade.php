
@include('MainLayouts/header')
@include('MainLayouts/mainheader')
    @include('MainLayouts/leftsidebar')
    @include('Admin/layouts/Admin/viewEditAdmin') 
@include('MainLayouts/footer')
